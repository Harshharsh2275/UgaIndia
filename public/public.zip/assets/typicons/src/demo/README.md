Font demo page templates. Generated code is a bit dirty, but it's done
intentionally, for easy maintenance & single file buldling